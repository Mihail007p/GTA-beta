// Service worker: игра работает без интернета после первого открытия.
// Стратегия: отдаём из кэша мгновенно, в фоне обновляем файл с сервера.
const CACHE = 'openstreet-v3';
const FILES = [
  './', './index.html', './css/style.css', './manifest.webmanifest',
  './icons/icon-192.png', './icons/icon-512.png', './vendor/three.js',
  './js/main.js', './js/config.js', './js/rng.js', './js/city.js', './js/car-physics.js', './js/cars.js',
  './js/collision.js', './js/traffic.js', './js/gameplay.js', './js/save.js', './js/textures.js',
  './js/car-model.js', './js/renderer.js', './js/audio.js', './js/input.js', './js/ui.js', './js/traffic-types.js',
  './vendor/GLTFLoader.js', './vendor/BufferGeometryUtils.js', './vendor/meshopt_decoder.module.js',
  // модели (~3.4 МБ): машины гаража и трафик — чтобы гараж работал и без интернета
  './assets/cars/cayenne.glb', './assets/cars/gt3.glb', './assets/cars/f458.glb', './assets/cars/cgt.glb',
  './assets/traffic.glb',
];
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== location.origin) return;
  e.respondWith(caches.open(CACHE).then(async (cache) => {
    const hit = await cache.match(req, { ignoreSearch: true });
    const net = fetch(req).then((res) => { if (res && res.ok) cache.put(req, res.clone()); return res; }).catch(() => null);
    return hit || (await net) || new Response('offline', { status: 503 });
  }));
});
